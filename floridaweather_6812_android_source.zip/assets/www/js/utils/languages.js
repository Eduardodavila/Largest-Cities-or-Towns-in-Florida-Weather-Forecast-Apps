
/** Auto-generated languages.js */
var AVAILABLE_LANGUAGES = new Array('ar','bn','ca','cs','da','de','en','en_GB','es','fr','hi','id','it','ja','nl','pa','pl','pt_BR','ru','sv','tr','zh','zh_Hans');

/**
 * Find navigator preferred language
 */
var language = "en";
if(navigator.language) {
    var tmp_language = navigator.language.replace("-", "_");

    try {
        if(AVAILABLE_LANGUAGES.indexOf(tmp_language) >= 0) {
            language = tmp_language
        } else {
            language = tmp_language.split("_")[0];
        }
    } catch(e) {
        language = "en";
    }
}