
/** Auto-generated url.js */
var REDIRECT_URI = false;
window.location.hash = window.location.hash.replace(/\?__goto__=(.*)/, "");
var CURRENT_LANGUAGE = AVAILABLE_LANGUAGES.indexOf(language) >= 0 ? language : 'en';
DOMAIN = 'https://app.mobimaticbuilder.com';
APP_KEY = '596cea0c1e6af';
BASE_PATH = '/'+APP_KEY;

var BASE_URL = DOMAIN + BASE_PATH;
var IMAGE_URL = DOMAIN + '/';